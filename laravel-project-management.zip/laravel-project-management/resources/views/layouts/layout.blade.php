<html>
    <head>
        <title>@yield('title')</title>
        <meta charset="utf-8">
    </head>
    <body>
        <main class="container">
            @yield('content')
        </main>
    </body>
</html>

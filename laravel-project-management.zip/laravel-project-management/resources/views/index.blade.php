@extends('layout')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel Project Management</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('userData.create') }}">
                    Create new project
                </a>
            </div>
        </div>
    </div>
    

    @if($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>No.</th>
            <th>Naziv</th>
            <th>Opis</th>
            <th>Status</th>
            <th>Nadlezni</th>
            <th>Datum Pocetka</th>
            <th>Datum zavrsetka</th>
        </tr>

        @foreach($userData as $user)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $user->naziv }}</td>
                <td>{{ $user->opis }}</td>
                <td>{{ $user->status }}</td>
                <td>{{ $user->nadlezni }}</td>
                <td>{{ $user->datumP }}</td>
                <td>{{ $user->datumZ }}</td>
                <td>
                    <form action="{{ route('userData.destroy', $user->id) }}" method="POST">
                        <a class="btn btn-info" 
                            href="{{ route('userData.show', $user->id) }}">
                            Show
                        </a>

                        <a class="btn btn-primary"
                            href="{{ route('userData.edit', $user->id) }}">
                            Edit
                        </a>

                        {{-- @csrf 
                        @method('DELETE')
                        --}}

                        {{ csrf_field() }}
                        {{ method_field('DELETE') }}

                        <button type="submit" class="btn btn-danger">
                            Delete
                        </button>

                    </form>
                </td>
            </tr>
        @endforeach
    </table>

    {!! $userData->links() !!}

@endsection
<html>
    <head>
        <meta charset="utf-8">
        <title>Hello!</title>
    </head>
    <body>
        <h1>Hello views blade stranica</h1>
        	
{{-- This is our comment, which is really classic PHP comment --}}
        <ul>
        @foreach ($names as $name)
            <li>{{ $name }} </li>
        @endforeach
        </ul>
    </body>
</html>
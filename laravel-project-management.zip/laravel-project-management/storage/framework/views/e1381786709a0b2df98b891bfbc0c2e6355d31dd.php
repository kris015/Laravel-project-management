 
 
<?php $__env->startSection('title', 'Projekti'); ?> 
 
<?php $__env->startSection('content'); ?>
<center>
    <h1>Svi projekti</h1>
    <p>Ovo su svi projekti koji se trenutno nalaze u bazi.</p> 
 
    <?php $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <style>
        ul{
            border:1px solid black;
            width:350px;
            list-style-type: none;
        }
    </style>
    <ul>
        <h4><a href="#"> <?php echo e($user->naziv); ?> </a></h4>
        <li>Opis projekta: <?php echo e($user->opis); ?> </li>
        <li>Trenutni status: <?php echo e($user->status); ?> </li>
        <li>Nadlezan za projekat: <?php echo e($user->nadlezni); ?> </li>
        <li>Datum pocetka: <?php echo e($user->datumP); ?> </li>
        <li>Datum zavrsetka: <?php echo e($user->datumZ); ?> </li><br>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekatant\resources\views/test3.blade.php ENDPATH**/ ?>
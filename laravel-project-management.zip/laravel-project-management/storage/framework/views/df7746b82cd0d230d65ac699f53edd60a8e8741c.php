<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta charset="utf-8">
    </head>
    <body>
        <main class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\projekatant\resources\views/layouts/layout.blade.php ENDPATH**/ ?>
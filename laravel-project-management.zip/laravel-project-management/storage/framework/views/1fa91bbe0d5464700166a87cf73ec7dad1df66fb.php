

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel Project Management</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('userData.create')); ?>">
                    Create new project
                </a>
            </div>
        </div>
    </div>
    

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No.</th>
            <th>Naziv</th>
            <th>Opis</th>
            <th>Status</th>
            <th>Nadlezni</th>
            <th>Datum Pocetka</th>
            <th>Datum zavrsetka</th>
        </tr>

        <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($user->naziv); ?></td>
                <td><?php echo e($user->opis); ?></td>
                <td><?php echo e($user->status); ?></td>
                <td><?php echo e($user->nadlezni); ?></td>
                <td><?php echo e($user->datumP); ?></td>
                <td><?php echo e($user->datumZ); ?></td>
                <td>
                    <form action="<?php echo e(route('userData.destroy', $user->id)); ?>" method="POST">
                        <a class="btn btn-info" 
                            href="<?php echo e(route('userData.show', $user->id)); ?>">
                            Show
                        </a>

                        <a class="btn btn-primary"
                            href="<?php echo e(route('userData.edit', $user->id)); ?>">
                            Edit
                        </a>

                        

                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>


                        <button type="submit" class="btn btn-danger">
                            Delete
                        </button>

                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $userData->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekatant\resources\views/index.blade.php ENDPATH**/ ?>
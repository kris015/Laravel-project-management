<div>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Test 1 View</title>
    </head>
    <body>
        <nav>
            <a href="/test1">Test 1</a>
            <a href="/test2">Test 2</a>
        </nav>
        <main>
            <?php echo e($slot); ?>

        </main>
    </body>
</html>
</div><?php /**PATH C:\xampp\htdocs\projekatant\resources\views/components/main.blade.php ENDPATH**/ ?>
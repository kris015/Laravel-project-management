<?php 
 
namespace Database\Factories; 
 
use App\Models\UserData;
use Illuminate\Database\Eloquent\Factories\Factory; 
 
/**
* @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\UserData>
*/
class UserDataFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */ 
 
    protected $model = UserData::class;
 
    public function definition()
    {
        return [
            'naziv' => $this->faker->naziv(),
            'opis' => $this->faker->opis(),
            'status' => $this->faker->status(),
            'nadlezni' => $this->faker->nadlezni(),
            'datumP' => date('Y-m-d'),
            'datumZ' => date('Y-m-d')
        ];
    }
}
